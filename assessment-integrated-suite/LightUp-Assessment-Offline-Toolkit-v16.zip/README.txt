LightUp PRIVATE Offline Assessment Toolkit
-------------------------------------------
SOFTWARE ONLY; NO CUSTOMER OR ASSESSMENT SOURCE DATA INCLUDED.

Extract this ZIP into a new private directory on an approved local computer.
Open START-HERE.html from disk. Do not publish/serve the files over HTTP.
All studios are complete original offline HTML assets from independently held
DRAFT/HOLD PR source snapshots. Use local file choosers manually.
Nothing in this ZIP grants client/operator consent, source authenticity,
authority to scan, vulnerability verification, release or deployment.

These source files are unsigned. manifest.json hashes are only local file-byte
integrity references; they do not authenticate source provenance.
Individual studios independently re-admit any PRIVATE local HUMAN/source data.
Avoid uploading private sources, reviewer notes or generated receipts.
Some studios need previously generated original LightUp artifacts.
Native checkout users can additionally prepare an original-source PRIVATE
casebook and source-byte ledger with assessment-integrated-suite/console.py
options 21/22. The same console now has 51 actions, including original
source-bound PRIVATE HUMAN finding selection, reply and sender triage
(options 23-31), exact-receipt PRIVATE disclosure HUMAN decisions and
suppressed HUMAN counts (32-34), and original HUMAN retention plan timeline
and drift (35-36). Source-specific workrooms still require native original
admission. An operator can now explicitly save and restore owner-only 0600
PATH-ONLY console sessions, view local PRIVATE workspace bookmarks and
compare 2-8 saved session path histories (37-39), and prepare a
source-free PRIVATE route board of existing local workrooms (40), or
read a STRICT saved owner-private session for an isolated route board without
changing the live console paths (41).
The native console also supports a source-PATH-snapshot-bound HUMAN work
queue CSV and offline owner-private HTML (42), strict HUMAN CSV reopen
against the exact unchanged session (43), a minimum-necessary single-team
PRIVATE HUMAN task deck (44) and a redacted 2-8 revision history (45).
An original saved 0600 session may resume the native offline HUMAN
browser workroom without replacing current paths (46), and a source-free
priority/declared-date/team workload board can be created locally (47).
The complete native PRIVATE workpack (48) now composes the original
source-bound interactive HUMAN queue, declared-date priorities, and
assigned-team-only task decks in one new 0700 local folder, using ONE
pinned owner-only 0600 HUMAN CSV snapshot for consistent child views.
For a FIRST workpack, options 48/49 accept an intentionally EMPTY CSV
selector and seed all 21 source-PATH-referenced workflow entries as
UNASSESSED (no HUMAN decision, owner, approval or authorization).
Provided existing original CSV files still require exact strict
source-PATH/session binding. An original strict saved session can
recreate this full workpack without modifying live console paths (49).
Native option 50 and suite.py workpack-progress can produce a separate
owner-private offline HUMAN stage/team/declared-date progression from 2-8
original exact-session workpack snapshots without copying question text.
This remains NATIVE-ONLY and is not bundled in browser-only software.
Native option 51 and suite.py workpack-continue re-admit an existing
original owner-only workpack from a strict unchanged saved session and
generate a fresh completely editable HUMAN workpack with a new explicitly
declared review date; old workpack unchanged. New v2 unsigned workpack
receipts bind the exact pinned 0600 CSV bytes/length; older v1 receipts
remain legacy admission without a digest. Option 50 now publishes a
source-minimal searchable offline Progress Cockpit with CSP-pinned local
JavaScript and an independent scriptless 0600 fallback. The native
console opens with a compact eight-group navigator; ALL shows every
original numeric action, ?keyword searches, HELP shows the manual
37->49->50->51 HUMAN-only flow. These are PRIVATE local workflows and
are never actual risk certification, consent, scan permission or a
production assessment service.

The browser can preview proposed imported HUMAN field changes without
revealing question text and bulk-assign staged visible tasks to a HUMAN
team without contacting recipients or granting any assessment authority.
Its browser-only HUMAN attention dashboard live-updates local HOLD,
unavailable originals, manually selected review date, upcoming declared
dates and team workloads, and can filter the workflow rows without hiding
any rows from full original CSV export. No real calendar is queried or set.
The original source-owned suite.py now also accepts a foreground
human-workpack CLI subcommand to reconstruct PRIVATE local HUMAN workpacks
from a strict original saved 0600 session. It requires an existing 0700
parent outside the checkout, unique folder, a HUMAN declared review date
and the EXACT 'BUILD PRIVATE WORKPACK' confirmation string. The original
HUMAN CSV remains optional, with strict re-admission when supplied.
The original queue editor supports a CSP SHA256-pinned source-bound
interactive PRIVATE browser UI, HUMAN bulk HOLD/NEEDS INPUT, undo/redo and
explicit custody acknowledgement after a requested browser CSV download.
No HUMAN stage ever means PASS or authorization. These owner-private native
functions contain sensitive local file: bookmarks and HUMAN question text,
and are deliberately NOT included in this browser-only software ZIP.
The session JSON may reveal confidential client folder names and must NEVER
be put in this ZIP.
All such PRIVATE outputs are created locally outside the checkout.
This ZIP is browser software only; it intentionally does NOT embed any
native Python programs, generated source-specific studio, or client sources.
A missing required original input means HOLD; never fabricate findings.

LightUp: INCUBATE M3/M7 · PLAN/LAB ONLY · DRAFT/HOLD.
Original source-owner, security/privacy/browser reviews, exact-head hosted &
permanently registered VPS CI, #177/#182/#829, true separately authenticated
current client and operator consent including at-use revocation, and explicit
HUMAN GO remain mandatory before release or real target activity.
