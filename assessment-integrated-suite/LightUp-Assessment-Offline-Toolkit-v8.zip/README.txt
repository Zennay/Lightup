LightUp PRIVATE Offline Assessment Toolkit
-------------------------------------------
SOFTWARE ONLY; NO CUSTOMER OR ASSESSMENT SOURCE DATA INCLUDED.

Extract this ZIP into a new private directory on an approved local computer.
Open START-HERE.html from disk. Do not publish/serve the files over HTTP.
All studios are complete original offline HTML assets from independently held
DRAFT/HOLD PR source snapshots. Use local file choosers manually.
Nothing in this ZIP grants client/operator consent, source authenticity,
authority to scan, vulnerability verification, release or deployment.

These source files are unsigned. manifest.json hashes are only local file-byte
integrity references; they do not authenticate source provenance.
Individual studios independently re-admit any PRIVATE local HUMAN/source data.
Avoid uploading private sources, reviewer notes or generated receipts.
Some studios need previously generated original LightUp artifacts.
Native checkout users can additionally prepare an original-source PRIVATE
casebook and source-byte ledger with assessment-integrated-suite/console.py
options 21/22. The same console now has 31 actions, including original
source-bound PRIVATE HUMAN finding selection, reply and sender triage
(options 23-31), exact-receipt PRIVATE disclosure HUMAN decisions and
suppressed HUMAN counts (32-34), and original HUMAN retention plan timeline
and drift (35-36). Source-specific workrooms still require native original
admission. An operator can now explicitly save and restore owner-only 0600
PATH-ONLY console sessions, view local PRIVATE workspace bookmarks and
compare 2-8 saved session path histories (37-39). The session JSON may
reveal confidential client folder names and must NEVER be put in this ZIP.
All such PRIVATE outputs are created locally outside the checkout.
This ZIP is browser software only; it intentionally does NOT embed any
native Python programs, generated source-specific studio, or client sources.
A missing required original input means HOLD; never fabricate findings.

LightUp: INCUBATE M3/M7 · PLAN/LAB ONLY · DRAFT/HOLD.
Original source-owner, security/privacy/browser reviews, exact-head hosted &
permanently registered VPS CI, #177/#182/#829, true separately authenticated
current client and operator consent including at-use revocation, and explicit
HUMAN GO remain mandatory before release or real target activity.
