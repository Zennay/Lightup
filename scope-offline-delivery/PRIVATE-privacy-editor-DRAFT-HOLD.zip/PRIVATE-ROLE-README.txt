LightUp PRIVATE HUMAN scope handoff — privacy-editor
INCUBATE M3/M7 PLAN/LAB ONLY — DRAFT/HOLD — REVIEW ONLY.
This bundle contains unchanged ORIGINAL source tools for exactly one human role,
not access credentials, a signed receipt, proof of privacy, or permission.
No bundled tool automatically contacts assets, grants work or performs scans.
First verify this ENTIRE original ZIP against a SHA-256 you obtained through an
authenticated, independent channel: python3 tools/role_pack.py inspect
  /path/to/received.zip --expected-sha256 <64-lowercase-hex>
Only then run: python3 tools/role_pack.py unpack RECEIVED.zip
  PRIVATE_PARENT/NEW_DIR --expected-sha256 ROLE-ZIP-SHA256
Use only a user-owned private parent; open the offline start page manually.
The encrypted HUMAN courier needs a strong unique passphrase exchanged separately.
A matching digest and encryption do not authenticate a sender or recipient.
Human review, consent and all LightUp original release/CI/security gates remain.
