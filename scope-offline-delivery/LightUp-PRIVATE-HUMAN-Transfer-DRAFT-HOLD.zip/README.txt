LightUp PRIVATE HUMAN scope delivery — INCUBATE M3/M7 DRAFT/HOLD
1. Extract this complete outer ZIP to a local private folder.
2. Verify the entire ZIP: python3 package.py inspect ORIGINAL.zip
3. Open START-HERE.html locally; never host it publicly.
   For HUMAN text, redact first with privacy/disclosure-preflight.html.
   Then encrypt the redacted note with courier/PRIVATE-encrypted-courier.html.
   Recipient decrypts, opens privacy/disclosure-recipient-verify.html and
   checks redacted exact bytes/receipt. Matching SHA is not identity.
   Portable inspector: python3 tools/package.py inspect ORIGINAL.zip
4. Or run: python3 tools/unpack.py ORIGINAL.zip PRIVATE_PARENT/NEW_DIR
   Then open NEW_DIR/original-workspace/scope-unified-workspace/index.html.
5. Open the separate encrypted courier to encrypt the original ZIP or HUMAN notes.
6. Browser-only: open PRIVATE-receive.html, compare original whole-ZIP digest
   from a separate authenticated channel, inspect original members, then build
   and intentionally save one role-specific source-only ZIP locally.
   Or for command-line packaging use tools/role_pack.py build ORIGINAL.zip
   PRIVATE_PARENT/NEW-ROLE.zip --profile privacy-recipient
   --expected-sha256 <separately-authenticated-original-outer-SHA256>.
   Other roles: privacy-editor, scope-reviewer. Parent must be private 0700.
7. Check recipient identity and exchange passwords through another trusted channel.
All hashes are unsigned. NO active target, authorization, grant, revoke, deployment,
verified remediation, fresh consent, independent review or HUMAN GO is implied.
