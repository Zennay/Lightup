LightUp PRIVATE HUMAN scope delivery — INCUBATE M3/M7 DRAFT/HOLD
1. Extract this complete outer ZIP to a local private folder.
2. Verify the entire ZIP: python3 package.py inspect ORIGINAL.zip
3. Open START-HERE.html locally; never host it publicly.
4. Extract the original inner workspace ZIP; open its index.html.
5. Open the separate encrypted courier to encrypt the original ZIP or HUMAN notes.
6. Check recipient identity and exchange passwords through another trusted channel.
All hashes are unsigned. NO active target, authorization, grant, revoke, deployment,
verified remediation, fresh consent, independent review or HUMAN GO is implied.
