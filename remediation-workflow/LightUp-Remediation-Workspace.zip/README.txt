LightUp · Offline Remediation Workspace
INCUBATE M3/M7 · PLAN/LAB ONLY · DRAFT/HOLD.

1. Open START-HERE.html locally.
2. Work in Evidence Review Board with a separately authorized original findings CSV.
3. Optionally import those exact original CSV bytes into Capacity Studio.
4. Export private Evidence JSON, optional Capacity draft JSON.
5. Open Coordination Cockpit and select the same exact original CSV with those files.
6. Independently confirm exact same client and engagement. Inspect human coordination.
7. Exports contain unverified local coordination notes, not proof of remediation.

The ZIP contains NO private client data, credentials, evidence, approval, grants,
actions, live scan code, or verified repair outcomes. It has no network runtime.
All release, security, review and consent gates remain HOLD.

Original branches are unchanged: Casework #1568, Evidence Review #1623,
Capacity Studio #1583. Composition remains an isolated draft source candidate.
