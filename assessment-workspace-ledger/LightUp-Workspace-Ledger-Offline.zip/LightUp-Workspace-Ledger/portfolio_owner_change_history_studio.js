/* Source-free LightUp PRIVATE original HUMAN operator history explorer.
 * Read-only preview of one original native single-owner history JSON. No
 * original HUMAN free-text notes, network, consent, identity or actual action.
 */
(() => {
"use strict";
const $=id=>document.getElementById(id);
const SCHEMA="lightup.private.workspace-ledger-human-operator-change-history.v1";
const KEYS=["schema","authority","historical_only","sources_reopened","recipient_authenticated","consent_assumed","actions_dispatched","appointments_booked","verified_remediation","original_owner_inbox_sha256","original_history_sha256","original_proposed_human_owner_label","original_human_operator_rounds","human_proposed_history_rows"];
const AUTH=["authorization","consent","verified_finding","release_approval"];
const ROUND=["ordinal","receipt_sha256","original_csv_sha256"];
const ROW=["original_proposed_human_owner_label","local_case","historical_transition","original_kit","original_owner_human_reply_stage","first_human_operator_stage","latest_human_operator_stage","human_stage_changed_in_rounds","private_human_note_changed_in_rounds","human_operator_stage_by_round"];
const STAGES=["needs_discussion","proposed_followup","hold"];
const MAX=1048576;
let records=[],original=null,rawHash="";
const exact=(x,keys)=>!!x&&typeof x==="object"&&!Array.isArray(x)&&Object.keys(x).length===keys.length&&keys.every(k=>Object.hasOwn(x,k));
const hexdigest=x=>typeof x==="string"&&/^[a-f0-9]{64}$/.test(x);
const safeName=x=>typeof x==="string"&&x.length>0&&x.length<=80&&x.trim()===x&&!/[\u0000-\u001f\u007f]/.test(x)&&!/^s*[=+@-]/.test(x);
function uniqueJson(raw){
 let at=0;
 const number=/-?(?:0|[1-9]d*)(?:.d+)?(?:[eE][+-]?d+)?/y;
 const word=/(?:true|false|null)/y;
 const ws=()=>{while(at<raw.length&&/[\r\n\t ]/.test(raw[at]))at++;};
 function quoted(){
   if(raw[at]!=='"')throw Error("Invalid source JSON quote");
   const first=at++;
   while(at<raw.length){
     let c=raw[at++];
     if(c==='"')return JSON.parse(raw.slice(first,at));
     if(c==="\\"){if(at===raw.length)throw Error("Invalid JSON escape");at++;}
   }
   throw Error("Incomplete source string");
 }
 function next(depth){
   if(depth>64)throw Error("Original source depth limit");
   ws();
   if(raw[at]==='{'){
     at++;ws();const seen=new Set();
     if(raw[at]==='}'){at++;return;}
     while(true){
       ws();const name=quoted();
       if(seen.has(name))throw Error("Duplicate original JSON key");
       seen.add(name);ws();if(raw[at++]!==':')throw Error("Invalid source JSON colon");
       next(depth+1);ws();const end=raw[at++];
       if(end==='}')return;
       if(end!==',')throw Error("Invalid source JSON object delimiter");
     }
   }
   if(raw[at]==='['){
     at++;ws();if(raw[at]===']'){at++;return;}
     while(true){
       next(depth+1);ws();const end=raw[at++];
       if(end===']')return;
       if(end!==',')throw Error("Invalid source JSON array delimiter");
     }
   }
   if(raw[at]==='"'){quoted();return;}
   number.lastIndex=at;const n=number.exec(raw);if(n){at=number.lastIndex;return;}
   word.lastIndex=at;const w=word.exec(raw);if(w){at=word.lastIndex;return;}
   throw Error("Invalid original source JSON token");
 }
 next(0);ws();
 if(at!==raw.length)throw Error("Trailing JSON bytes");
 return JSON.parse(raw);
}
function validate(doc){
 if(!exact(doc,KEYS)||doc.schema!==SCHEMA||!exact(doc.authority,AUTH)||
   !AUTH.every(k=>doc.authority[k]===false)||doc.historical_only!==true||
   !["sources_reopened","recipient_authenticated","consent_assumed","actions_dispatched","appointments_booked","verified_remediation"].every(k=>doc[k]===false)||
   !hexdigest(doc.original_owner_inbox_sha256)||!hexdigest(doc.original_history_sha256)||
   !safeName(doc.original_proposed_human_owner_label)||
   !Array.isArray(doc.original_human_operator_rounds)||
   doc.original_human_operator_rounds.length<2||doc.original_human_operator_rounds.length>8||
   !Array.isArray(doc.human_proposed_history_rows)||
   !doc.human_proposed_history_rows.length||doc.human_proposed_history_rows.length>2048)
   throw Error("Not native original private HUMAN operator history");
 const known=new Set(),roundHashes=new Set(),total=doc.original_human_operator_rounds.length;
 for(const [i,r] of doc.original_human_operator_rounds.entries()){
   if(!exact(r,ROUND)||r.ordinal!==i+1||
     !hexdigest(r.receipt_sha256)||!hexdigest(r.original_csv_sha256)||
     roundHashes.has(r.receipt_sha256))throw Error("Historical original HUMAN version invalid");
   roundHashes.add(r.receipt_sha256);
 }
 for(const r of doc.human_proposed_history_rows){
   const id=r?.local_case+":"+r?.historical_transition+":"+r?.original_kit;
   if(!exact(r,ROW)||r.original_proposed_human_owner_label!==doc.original_proposed_human_owner_label||
     !Number.isInteger(r.local_case)||r.local_case<1||r.local_case>8||
     !Number.isInteger(r.historical_transition)||r.historical_transition<1||r.historical_transition>11||
     !Number.isInteger(r.original_kit)||r.original_kit<1||r.original_kit>12||
     known.has(id)||!STAGES.includes(r.original_owner_human_reply_stage)||
     !STAGES.includes(r.first_human_operator_stage)||!STAGES.includes(r.latest_human_operator_stage)||
     !Array.isArray(r.human_operator_stage_by_round)||r.human_operator_stage_by_round.length!==total||
     !r.human_operator_stage_by_round.every(s=>STAGES.includes(s))||
     r.human_operator_stage_by_round[0]!==r.first_human_operator_stage||
     r.human_operator_stage_by_round[total-1]!==r.latest_human_operator_stage||
     !Array.isArray(r.human_stage_changed_in_rounds)||
     !Array.isArray(r.private_human_note_changed_in_rounds))
       throw Error("Original HUMAN historical row inconsistent");
   const expected=[];
   for(let i=1;i<total;i++){
     if(r.human_operator_stage_by_round[i]!==r.human_operator_stage_by_round[i-1])expected.push(i+1);
   }
   if(JSON.stringify(expected)!==JSON.stringify(r.human_stage_changed_in_rounds))
     throw Error("Stage changes do not match original source");
   const notes=r.private_human_note_changed_in_rounds;
   if(notes.some((v,i)=>!Number.isInteger(v)||v<2||v>total||(i>0&&v<=notes[i-1])))
     throw Error("Invalid PRIVATE HUMAN note change rounds");
   known.add(id);
 }
 return doc.human_proposed_history_rows.slice();
}
const element=(tag,text,cls)=>{
 const e=document.createElement(tag);if(text!==undefined)e.textContent=String(text);
 if(cls)e.className=cls;return e;
};
const say=x=>{$("status").textContent=x;};
function clear(){
 original=null;records=[];rawHash="";
 $("source").value="";$("room").hidden=true;$("cards").replaceChildren();
 $("query").value="";$("round").replaceChildren(element("option","Latest original HUMAN round"));
 $("round").firstChild.value="latest";$("stage").value="";$("changed").value="all";
 say("Original private HUMAN browser memory cleared.");
}
function choice(){
 return $("round").value==="latest"?original.original_human_operator_rounds.length-1:Number($("round").value)-1;
}
function filtered(){
 const n=choice(),stage=$("stage").value,changed=$("changed").value,
 term=$("query").value.trim().toLocaleLowerCase();
 return records.filter(r=>{
   if(stage&&r.human_operator_stage_by_round[n]!==stage)return false;
   if(changed==="stage"&&!r.human_stage_changed_in_rounds.length)return false;
   if(changed==="note"&&!r.private_human_note_changed_in_rounds.length)return false;
   if(changed==="both"&&!(r.human_stage_changed_in_rounds.length&&r.private_human_note_changed_in_rounds.length))return false;
   if(changed==="stable"&&(r.human_stage_changed_in_rounds.length||r.private_human_note_changed_in_rounds.length))return false;
   return !term||(
       r.local_case+" "+r.historical_transition+" "+r.original_kit+" "+
       r.human_operator_stage_by_round.join(" ")
   ).toLocaleLowerCase().includes(term);
 });
}
function render(){
 if(!original)return;
 const subset=filtered(),round=choice(),cards=$("cards");cards.replaceChildren();
 $("summary").textContent=records.length+" ORIGINAL HUMAN owner proposal slots • "+
 original.original_human_operator_rounds.length+" manually ordered HUMAN versions • "+
 "one original proposed owner (NOT authenticated)";
 $("visible").textContent=subset.length+" visible HUMAN slots · "+
 STAGES.map(s=>s.replaceAll("_"," ")+": "+subset.filter(r=>r.human_operator_stage_by_round[round]===s).length).join(" · ");
 for(const r of subset){
   const article=element("article",undefined,"card");
   article.append(element("h3","Original HUMAN source "+r.local_case+" / "+r.historical_transition+" / "+r.original_kit));
   const facts=element("div",undefined,"facts");
   for(const [k,v] of [
     ["Original received HUMAN owner stage",r.original_owner_human_reply_stage],
     ["HUMAN operator proposal in selected round",r.human_operator_stage_by_round[round]],
     ["Manual HUMAN stage progression",r.human_operator_stage_by_round.join(" → ")],
     ["HUMAN stage changed in rounds",r.human_stage_changed_in_rounds.join(", ")||"none"],
     ["PRIVATE note changed in rounds (not contents)",r.private_human_note_changed_in_rounds.join(", ")||"none"]
   ]){const row=element("div",undefined,"fact");
      row.append(element("strong",k),element("span",v));facts.append(row);}
   article.append(facts);cards.append(article);
 }
 if(!subset.length)cards.append(element("p","No original HUMAN proposal matches. This does NOT prove remediation."));
}
async function openFile(event){
 const file=event.target.files?.[0];
 if(!file||file.size<=0||file.size>MAX||!file.name.toLowerCase().endsWith(".json")){
   say("PRIVATE HOLD: one original owner-private native history JSON ≤1 MiB required");return;
 }
 try{
   const buffer=await file.arrayBuffer();
   if(buffer.byteLength!==file.size||!crypto.subtle)throw Error("Local unsigned source SHA unavailable");
   const doc=uniqueJson(new TextDecoder("utf-8",{fatal:true}).decode(buffer));
   const items=validate(doc);
   const hash=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",buffer)),
      x=>x.toString(16).padStart(2,"0")).join("");
   original=doc;records=items;rawHash=hash;
   const s=$("round");s.replaceChildren(element("option","Latest HUMAN proposal"));
   s.firstChild.value="latest";
   for(let i=1;i<=doc.original_human_operator_rounds.length;i++){
      const option=element("option","Manually ordered HUMAN version "+i);option.value=String(i);s.append(option);
   }
   $("query").value="";$("stage").value="";$("changed").value="all";
   $("room").hidden=false;render();
   say("PRIVATE HUMAN-only history locally opened. Unsigned SHA-256: "+rawHash+". No authenticated person or security verdict.");
 }catch(e){say("PRIVATE HOLD: original history rejected ("+(e?.message||"invalid")+"). Existing view retained.");}
}
function exportCounts(){
 if(!original)return;
 const items=filtered(),at=choice();
 const summary={
    schema:"lightup.private.anonymous-human-operator-version-counts.v1",
    authority:{authorization:false,consent:false,verified_finding:false,release_approval:false},
    historical_only:true,selected_human_round:at+1,
    visible_original_human_slots:items.length,
    proposed_human_stages:Object.fromEntries(STAGES.map(s=>[
       s,items.filter(r=>r.human_operator_stage_by_round[at]===s).length])),
    stage_changed_human_slots:items.filter(r=>r.human_stage_changed_in_rounds.length).length,
    private_note_changed_human_slots:items.filter(r=>r.private_human_note_changed_in_rounds.length).length,
 };
 const url=URL.createObjectURL(new Blob([JSON.stringify(summary,null,2)+"\n"],{type:"application/json"}));
 const a=element("a");a.href=url;a.download="LightUp-anonymous-HUMAN-operator-history-counts.json";
 document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),500);
 say("Anonymous HUMAN-only original counts exported; no owner labels or original source IDs.");
}
$("source").addEventListener("change",openFile);
$("round").addEventListener("change",render);
$("stage").addEventListener("change",render);
$("changed").addEventListener("change",render);
$("query").addEventListener("input",render);
$("clear").addEventListener("click",clear);
$("counts").addEventListener("click",exportCounts);
window.addEventListener("pagehide",clear);
say("Choose original PRIVATE-HUMAN-operator-version-history.json. Software contains no original client/HUMAN data.");
})();
