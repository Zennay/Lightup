"use strict";
// PRIVATE, in-tab-only file handoff shelf. Never parses source authority or calls network.
(() => {
  const MAX_ITEMS = 16;
  const MAX_FILE = 8 * 1024 * 1024;
  const MAX_TOTAL = 32 * 1024 * 1024;
  const routes = Object.freeze({
    none: ["Handmatig beoordelen", ""],
    studio: ["Scope Studio", "../studio/index.html"],
    intake: ["Scope Intake Matrix", "../scope-intake-matrix/standalone.html"],
    casebook: ["Casebook Transfer", "../scope-casebook-transfer/standalone.html"],
    reconcile: ["Casebook Reconcile", "../scope-casebook-reconcile/standalone.html"],
    risk: ["Authorization Risk Portfolio", "../authorization-portfolio/standalone.html"],
    stop: ["Withdrawal / STOP Desk", "../withdrawal-desk/standalone.html"],
    vault: ["Private Scope Packet Vault", "../scope-vault/standalone.html"]
  });
  const stages = Object.freeze({
    unreviewed: "Nog niet beoordeeld (HUMAN)",
    preparing: "Menselijk onderzoek loopt (HUMAN)",
    escalated: "Menselijke escalatie nodig (HUMAN)",
    documented: "Opvolging gedocumenteerd (NIET opgelost)"
  });
  const teams = Object.freeze({
    unassigned: "Nog geen team", security: "Security", privacy: "Privacy",
    client_ops: "Client operations", platform: "Platform"
  });
  const items = [];
  let busy = false;
  let generation = 0;
  const el = (id) => document.getElementById(id);
  const input = el("shelf-files");
  const rows = el("shelf-rows");
  const message = el("shelf-status");
  const summary = el("shelf-summary");
  const sourceCopy = el("private-copy");
  const anonymousCopy = el("counts-copy");
  const stageFilter = el("shelf-stage-filter");
  const searchFilter = el("shelf-search");
  const driftFile = el("shelf-drift-file");
  const driftStatus = el("shelf-drift-status");
  const driftRows = el("shelf-drift-rows");
  const driftExport = el("shelf-drift-export");
  let driftReview = null;
  const invalidateDrift = () => {
    driftReview = null;
    driftRows.replaceChildren();
    driftExport.disabled = true;
    driftStatus.textContent = "Bronselectie gewijzigd; vergelijk opnieuw met de eerdere PRIVATE inventaris.";
  };
  const SHA = (bytes) => crypto.subtle.digest("SHA-256", bytes).then((x) =>
    Array.from(new Uint8Array(x), (n) => n.toString(16).padStart(2, "0")).join(""));
  const cleanName = (name) => typeof name === "string" && name.length > 0 &&
    name.length <= 220 && !/[\x00-\x1f\x7f]/.test(name);
  const report = (text) => { message.textContent = text; };
  const cell = (row, value, cls) => {
    const c = document.createElement("td");
    if (cls) c.className = cls;
    c.textContent = value;
    row.append(c);
    return c;
  };
  const link = (href, label) => {
    const a = document.createElement("a");
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = label;
    a.className = "shelf-open";
    return a;
  };
  const download = (file, name) => {
    const url = URL.createObjectURL(file);
    try {
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      document.body.append(a);
      a.click();
      a.remove();
    } finally {
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
  };
  const exportJSON = (name, documentBody) => {
    const blob = new Blob([JSON.stringify(documentBody, null, 2) + "\n"], { type: "application/json" });
    download(blob, name);
  };
  const viewSummary = () => items.length
    ? items.length + " PRIVATE bronbestanden · " + items.reduce((s, e) => s + e.file.size, 0).toLocaleString("nl-NL") +
      " bytes · " + items.filter((e) => e.stage === "escalated").length + " HUMAN escalaties · " +
      items.filter((e) => e.stage === "unreviewed").length + " onbeoordeeld · NOOIT GEAUTORISEERD"
    : "Nog geen PRIVATE bestanden ingeladen. Geen inhoud of bestandsnaam wordt opgeslagen.";
  function render() {
    rows.replaceChildren();
    summary.textContent = viewSummary();
    for (const item of items) {
      if (stageFilter.value !== "all" && item.stage !== stageFilter.value) continue;
      if (searchFilter.value.trim() && !item.file.name.normalize("NFC").toLowerCase().includes(searchFilter.value.trim().normalize("NFC").toLowerCase())) continue;
      const tr = document.createElement("tr");
      cell(tr, item.file.name, "file-name");
      cell(tr, item.file.size.toLocaleString("nl-NL") + " B");
      cell(tr, item.hash, "hash");
      cell(tr, item.inspection.label + " · uitsluitend structurele hint", "kind");
      const routeCell = document.createElement("td");
      const select = document.createElement("select");
      select.setAttribute("aria-label", "HANDMATIGE routing voor " + item.file.name);
      for (const [id, info] of Object.entries(routes)) {
        const opt = document.createElement("option");
        opt.value = id;
        opt.textContent = info[0];
        select.append(opt);
      }
      select.value = item.route;
      select.addEventListener("change", () => {
        if (!Object.hasOwn(routes, select.value)) return;
        item.route = select.value;
        render();
      });
      routeCell.append(select);
      tr.append(routeCell);
      const triage = document.createElement("td");
      const addChoice = (label, options, value, update) => {
        const caption = document.createElement("label");
        caption.textContent = label;
        const picker = document.createElement("select");
        picker.setAttribute("aria-label", label + " voor " + item.file.name);
        for (const [key, name] of Object.entries(options)) {
          const option = document.createElement("option");
          option.value = key;
          option.textContent = name;
          picker.append(option);
        }
        picker.value = value;
        picker.addEventListener("change", () => {
          if (!Object.hasOwn(options, picker.value)) return;
          update(picker.value);
          summary.textContent = viewSummary();
        });
        caption.append(picker);
        triage.append(caption);
      };
      addChoice("HUMAN reviewfase", stages, item.stage, (v) => { item.stage = v; });
      addChoice("HUMAN opvolgteam", teams, item.team, (v) => { item.team = v; });
      const privateLabel = document.createElement("label");
      privateLabel.textContent = "Optionele PRIVATE opvolgnotitie (max. 280 tekens)";
      const note = document.createElement("textarea");
      note.maxLength = 280;
      note.rows = 2;
      note.value = item.note;
      note.setAttribute("aria-label", "PRIVATE opvolgnotitie voor " + item.file.name);
      note.addEventListener("input", () => {
        item.note = note.value;
      });
      privateLabel.append(note);
      triage.append(privateLabel);
      tr.append(triage);
      const actions = document.createElement("td");
      if (routes[item.route][1]) actions.append(link(routes[item.route][1], "Open werkruimte ↗"));
      const save = document.createElement("button");
      save.type = "button";
      save.className = "plain-action";
      save.textContent = "Origineel opnieuw opslaan";
      save.addEventListener("click", () => {
        if (confirm("PRIVATE origineel lokaal opnieuw opslaan? Dit verifieert geen authenticiteit, consent of scope.")) {
          download(item.file, item.file.name);
        }
      });
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "plain-action danger";
      remove.textContent = "Verwijder";
      remove.addEventListener("click", () => {
        generation++;
        invalidateDrift();
        items.splice(items.indexOf(item), 1);
        render();
        report("REVIEW_ONLY — bestand uit huidige lokale werkset verwijderd; bestaande schijfbestanden blijven bestaan.");
      });
      actions.append(save, remove);
      tr.append(actions);
      rows.append(tr);
    }
    if (items.length) summary.textContent += " · " + rows.childElementCount + " zichtbaar na lokale filters";
  }
  stageFilter.addEventListener("change", render);
  searchFilter.addEventListener("input", render);
  input.addEventListener("change", async () => {
    const chosen = Array.from(input.files || []);
    input.value = "";
    if (!chosen.length || busy) return;
    const bytes = chosen.reduce((sum, file) => sum + file.size, 0);
    if (items.length + chosen.length > MAX_ITEMS || bytes + items.reduce((sum, e) => sum + e.file.size, 0) > MAX_TOTAL ||
        chosen.some((file) => file.size < 1 || file.size > MAX_FILE || !cleanName(file.name))) {
      report("HOLD — hele nieuwe batch afgewezen: max. 16 bestanden, 8 MiB per bestand, 32 MiB totaal, zonder control-tekens.");
      return;
    }
    if (!globalThis.crypto || !crypto.subtle) {
      report("HOLD — lokale Web Crypto SHA-256 ontbreekt. Er is niets toegevoegd.");
      return;
    }
    busy = true;
    const epoch = generation;
    input.disabled = true;
    report("Lokale SHA-256 berekening; bestanden verlaten de browser niet…");
    try {
      const proposed = [];
      const existing = new Set(items.map((e) => e.hash));
      const names = new Set(items.map((e) => e.file.name.normalize("NFC").toLowerCase()));
      for (const file of chosen) {
        if (epoch !== generation) throw new Error("cancelled");
        const key = file.name.normalize("NFC").toLowerCase();
        if (names.has(key)) throw new Error("name-conflict");
        names.add(key);
        const inspection = await LightUpPrivateSourceInspector.inspect(file);
        if (epoch !== generation) throw new Error("cancelled");
        const hash = await SHA(await file.arrayBuffer());
        if (existing.has(hash)) throw new Error("duplicate");
        existing.add(hash);
        proposed.push({ file, hash, inspection, route: inspection.route, stage: "unreviewed", team: "unassigned", note: "" });
      }
      if (epoch !== generation) throw new Error("cancelled");
      generation++;
      invalidateDrift();
      items.push(...proposed);  // atomic admission
      render();
      report("REVIEW_ONLY — nieuwe PRIVATE bestanden en SHA-256 lokaal geladen. Structurele bronherkenning is géén bron-/toestemmingsvalidatie.");
    } catch (error) {
      report(error && error.message === "name-conflict"
        ? "HOLD — dubbele of tegenstrijdige oorspronkelijke bestandsnaam. Bestaande bron blijft intact; verwijder bewust eerst een oude versie en selecteer opnieuw."
        : "HOLD — formaat onduidelijk/ongeldig, bronclaim tegenstrijdig, import geannuleerd of identieke bytes al aanwezig. Hele nieuwe batch geweigerd; vorige werkset behouden.");
    } finally {
      busy = false;
      input.disabled = false;
    }
  });
  driftFile.addEventListener("change", async () => {
    const prior = driftFile.files && driftFile.files[0];
    driftFile.value = "";
    if (!prior || busy) return;
    invalidateDrift();
    if (!items.length) {
      driftStatus.textContent = "HOLD — selecteer eerst de actuele originele bestanden. Afwezig in een tabblad betekent geen ingetrokken grant.";
      return;
    }
    busy = true;
    input.disabled = true;
    driftFile.disabled = true;
    const epoch = generation;
    try {
      const older = await LightUpPrivateSourceInspector.readHumanInventory(prior);
      if (epoch !== generation) throw Error("source set changed during comparison");
      const result = LightUpPrivateDrift.compare(older, items);
      if (epoch !== generation) throw Error("source changed during comparison");
      for (const row of result.rows) {
        const tr = document.createElement("tr");
        cell(tr, row.original_name, "file-name");
        cell(tr, row.human_action, row.status === "UNCHANGED" ? "" : "kind");
        cell(tr, row.previous_unsigned_sha256 || "—", "hash");
        cell(tr, row.selected_unsigned_sha256 || "—", "hash");
        driftRows.append(tr);
      }
      driftReview = result;
      driftExport.disabled = false;
      driftStatus.textContent = "REVIEW_ONLY · " + result.totals.UNCHANGED + " zelfde bronbytes · " +
        result.totals.CHANGED_REVIEW_REQUIRED + " veranderd · " +
        result.totals.NEW_REVIEW_REQUIRED + " nieuw geselecteerd · " +
        result.totals.ABSENT_FROM_LOCAL_SELECTION + " niet opnieuw geselecteerd. " +
        "Iedere verandering vraagt afzonderlijke echte bron-/consentcontrole; geen auto-carry van HUMAN-statussen.";
    } catch (_) {
      invalidateDrift();
      driftStatus.textContent = "HOLD — onleesbare/onbetrouwbare vorige PRIVATE inventaris of bronselectie gewijzigd. Geen vergelijking of bronmutatie uitgevoerd.";
    } finally {
      busy = false;
      input.disabled = false;
      driftFile.disabled = false;
    }
  });
  driftExport.addEventListener("click", () => {
    if (!driftReview) return;
    if (!confirm("PRIVATE bronverschil-export maken met originele bestandsnamen en SHA-256? Dit is slechts historische lokale waarneming, geen revocation of consent, en kan identiteiten onthullen.")) return;
    exportJSON("lightup-scope-PRIVATE-original-source-drift.json", {
      format: "lightup.scope_handoff_PRIVATE_drift_review.v1", disposition: "REVIEW_ONLY",
      authority: { client_consent: false, operator_consent: false, grant: false,
        scan: false, deploy: false, release: false },
      counts: driftReview.totals, comparisons: driftReview.rows,
      disclaimer: "Unsigned local history. ABSENT does not mean withdrawn, CHANGED does not imply remediated. Never use as permission or source authorization."
    });
    report("REVIEW_ONLY — expliciet PRIVATE bronverschil lokaal gedownload; alle oorspronkelijke HUMAN-keuzes ongewijzigd.");
  });
  const restoreInput = el("shelf-review-reopen");
  restoreInput.addEventListener("change", async () => {
    const backup = restoreInput.files && restoreInput.files[0];
    restoreInput.value = "";
    if (!backup || busy) return;
    if (!items.length) {
      report("HOLD — importeer eerst exact dezelfde oorspronkelijke bestanden en volgorde voordat HUMAN-keuzes mogen terugkomen.");
      return;
    }
    busy = true;
    restoreInput.disabled = true;
    input.disabled = true;
    const epoch = generation;
    try {
      const rows = await LightUpPrivateSourceInspector.readHumanInventory(backup);
      if (epoch !== generation || rows.length !== items.length) {
        throw Error("different source set or concurrent clear");
      }
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i], original = items[i];
        if (row.original_name !== original.file.name ||
            row.byte_length !== original.file.size ||
            row.unsigned_sha256 !== original.hash ||
            row.structural_kind_unverified !== original.inspection.kind) {
          throw Error("source bytes, name, order or kind changed");
        }
      }
      if (!confirm("PRIVATE HUMAN-keuzes herstellen voor exact " + rows.length +
          " opnieuw geselecteerde originele bestanden? Alleen lokale route, HUMAN fase, team en notities veranderen. Geen echte autorisatie, bronwijziging of grant.")) {
        report("REVIEW_ONLY — herstel geannuleerd; bestaande HUMAN werkset ongewijzigd.");
        return;
      }
      if (epoch !== generation) throw Error("source set changed before replacement");
      for (let i = 0; i < rows.length; i++) {
        items[i].route = rows[i].human_route;
        items[i].stage = rows[i].human_stage;
        items[i].team = rows[i].human_team;
        items[i].note = rows[i].private_human_note;
      }
      render();
      report("REVIEW_ONLY — exacte originele source-bytes en volgorde herkend; uitsluitend PRIVATE HUMAN-reviewkeuzes hersteld. Nooit toestemming of revocation.");
    } catch (_) {
      report("HOLD — onjuist/ambigue PRIVATE plan of andere originele bestanden. Geen enkele bestaande HUMAN-keuze is gewijzigd.");
    } finally {
      busy = false;
      restoreInput.disabled = false;
      input.disabled = false;
    }
  });
  el("shelf-clear").addEventListener("click", () => {
    if (!items.length && !busy) return;
    if (!confirm("Alle PRIVATE bestandshandles uit dit tabblad wissen? Je oorspronkelijke bestanden blijven op schijf.")) return;
    generation++; // invalidate any asynchronous import in flight
    invalidateDrift();
    items.splice(0);
    render();
    report("REVIEW_ONLY — tabblad-werkset gewist. Browser/JavaScript garanderen geen fysieke geheugenwissing.");
  });
  anonymousCopy.addEventListener("click", () => {
    if (!items.length) return report("HOLD — er is nog niets voor een bronvrije telling geselecteerd.");
    if (!confirm("Bronvrij HUMAN-exportje met aantallen delen? Kleine aantallen kunnen in context toch gevoelig zijn.")) return;
    const byRoute = Object.fromEntries(Object.keys(routes).map((k) => [k, 0]));
    for (const item of items) byRoute[item.route] += 1;
    exportJSON("lightup-scope-handoff-anonymous-counts.json", {
      format: "lightup.scope_handoff_anonymous_counts.v1", status: "REVIEW_ONLY",
      authority: { client_consent: false, operator_consent: false, grant: false, scan: false, deploy: false, release: false },
      number_of_local_files: items.length, human_selected_routes: byRoute,
      warning: "Only tentative human routing counts; not original source, authentication, permission or safety evidence."
    });
    report("REVIEW_ONLY — alleen aantallen gedownload, zonder namen, digests of inhoud.");
  });
  sourceCopy.addEventListener("click", () => {
    if (!items.length) return report("HOLD — geen PRIVATE bronbestanden geselecteerd.");
    if (!confirm("PRIVATE INVENTARIS exporteren inclusief originele bestandsnamen, bytes en SHA-256? Kan klant- of projectdetails onthullen. Deel uitsluitend met bedoelde, apart geauthenticeerde ontvanger.")) return;
    exportJSON("lightup-scope-handoff-PRIVATE-source-inventory.json", {
      format: "lightup.scope_handoff_PRIVATE_inventory.v1", status: "REVIEW_ONLY",
      authority: { client_consent: false, operator_consent: false, grant: false, scan: false, deploy: false, release: false },
      entries: items.map((e) => ({ original_name: e.file.name, byte_length: e.file.size,
        unsigned_sha256: e.hash, structural_kind_unverified: e.inspection.kind,
        human_route: e.route, human_stage: e.stage, human_team: e.team, private_human_note: e.note })),
      warning: "PRIVATE unsigned inventory, never source or recipient authentication. No file content included."
    });
    report("REVIEW_ONLY — expliciete PRIVATE ongetekende bestandsinventaris lokaal gedownload.");
  });
  render();
  window.addEventListener("pagehide", () => {
    generation++;  // never repopulate a private tab after navigation / bfcache
    invalidateDrift();
    items.splice(0);
  });
})();
